                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2531066
Laser cutting plan secret hitler print and play by Nowa is licensed under the Creative Commons - Attribution - Share Alike license.
http://creativecommons.org/licenses/by-sa/3.0/

# Summary

Laser cutting plans for the Secret Hitler print and play.
The red lines (0.1 mm thick) are cutting lines and greyscale is for engraving.

You can download the game officially for free here: http://secrethitler.com

The "Vorderseite.svg" file contains the required boards, tiles, cards and placard.
If you like you can add some engraving on the back side (Rückseite.svg OR Rückseite_alternative.svg). 

Additional font used: Deutsch-Gotisch

I used 3 mm plywood (birch) for the boards, placards/tabs and the pile cards along with 2 mm plywood for the remaining cards.

Lasercutter: Trotec Speedy 100R (30 Watt, CO2-Laser), engraving resolution: 600 dpi

Note: The tiles and cards are adjusted in size for my liking. :P